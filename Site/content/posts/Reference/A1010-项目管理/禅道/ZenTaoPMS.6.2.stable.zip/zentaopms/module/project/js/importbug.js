$(function()
{
    $('#' + browseType + 'Tab').addClass('active');
    ajaxGetSearchForm();
});

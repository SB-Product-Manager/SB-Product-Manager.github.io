<?php
/**
 * The export view file of bug module of ZenTaoPMS.
 *
 * @copyright   Copyright 2009-2013 青岛易软天创网络科技有限公司 (QingDao Nature Easy Soft Network Technology Co,LTD www.cnezsoft.com)
 * @license     LGPL (http://www.gnu.org/licenses/lgpl.html)
 * @author      Yangyang Shi<shiyangyang@cnezsoft.com>
 * @package     todo 
 * @version     $Id$
 * @link        http://www.zentao.net
 */
?>
<?php include '../../file/view/export.html.php';?>

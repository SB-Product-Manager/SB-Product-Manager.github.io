$(function()
{
    if(browseType == 'bysearch') ajaxGetSearchForm();
})

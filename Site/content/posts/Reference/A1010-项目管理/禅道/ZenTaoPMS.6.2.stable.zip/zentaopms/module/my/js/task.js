$(function()
{
    $('#' + type + 'Tab').addClass('active');
})

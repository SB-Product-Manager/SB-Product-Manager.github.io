$(document).ready(function()
{
    $('#' + browseType + 'Tab').addClass('active');
});
